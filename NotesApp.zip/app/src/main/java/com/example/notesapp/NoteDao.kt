import androidx.room.*

@Dao
internal interface NoteDao {
    val allNotes: Unit
    fun insert()
    fun update()

    fun delete()

    companion object {
        val `fun`: suspend ? = null
        val `fun`: suspend ? = null
        val `fun`: suspend ? = null
        val `fun`: suspend ? = null
    }
}