import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class NoteDialog(
    context: Context,
    private val note: NoteEntity?,
    private val onSave: (NoteEntity) -> Unit
) : Dialog(context) {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dialog_note)

        val etTitle = findViewById<EditText>(R.id.etTitle)
        val etContent = findViewById<EditText>(R.id.etContent)
        val btnSave = findViewById<Button>(R.id.btnSave)
        val btnCancel = findViewById<Button>(R.id.btnCancel)

        if (note != null) {
            etTitle.setText(note.title)
            etContent.setText(note.content)
        }

        btnSave.setOnClickListener {
            val title = etTitle.text.toString()
            val content = etContent.text.toString()
            val newNote = NoteEntity(note?.id ?: 0, title, content)
            onSave(newNote)
            dismiss()
        }
        btnCancel.setOnClickListener { dismiss() }
    }
}